<template>
	 <button>{{name}}</button>
</template>

<script>
	export default
	{
		props:['name']
	}
</script>